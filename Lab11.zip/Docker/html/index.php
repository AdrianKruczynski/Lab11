<?php
phpinfo(); 
?>
